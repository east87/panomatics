/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) { 
	var path = 'https://localhost/panom/assets/tools';
//	config.filebrowserBrowseUrl = path+'/kcfinders/browse.php?type=files';
//	config.filebrowserImageBrowseUrl = path+'/kcfinders/browse.php?type=images';
//	config.filebrowserFlashBrowseUrl = path+'/kcfinders/browse.php?type=flash';
//	config.filebrowserUploadUrl = path+'/kcfinders/upload.php?type=files';
//	config.filebrowserImageUploadUrl = path+'/kcfinders/upload.php?type=images';
//	config.filebrowserFlashUploadUrl = path+'/kcfinders/upload.php?type=flash';
//        
   config.filebrowserBrowseUrl = path+'/kcfinder/browse.php?opener=ckeditor&type=files';
   config.filebrowserImageBrowseUrl = path+'/kcfinder/browse.php?opener=ckeditor&type=images';
   config.filebrowserFlashBrowseUrl = '/kcfinder/browse.php?opener=ckeditor&type=flash';
   config.filebrowserUploadUrl = path+'/kcfinder/upload.php?opener=ckeditor&type=files';
   config.filebrowserImageUploadUrl = path+'/kcfinder/upload.php?opener=ckeditor&type=images';
   config.filebrowserFlashUploadUrl = path+'/kcfinder/upload.php?opener=ckeditor&type=flash';
        
	config.allowedContent = true;
        config.autoParagraph = false;
	config.enterMode = CKEDITOR.ENTER_BR // pressing the ENTER Key puts the <br/> tag
        config.shiftEnterMode = CKEDITOR.ENTER_P; //pressing the SHIFT + ENTER Keys puts the <p> tag
        
	config.toolbar = [
		{ name: 'document', items : [ 'Source'] },
		{ name: 'clipboard', items : [ 'Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo' ] },
		{ name: 'editing', items : [ 'Find','Replace','-','SelectAll','-','Scayt' ] },
		{ name: 'insert', items : [ 'Youtube','Image','Flash','Table','HorizontalRule','Smiley','SpecialChar','PageBreak'
				 ,'Iframe' ] },
				'/',
		{ name: 'styles', items : [ 'Styles','Format' ] },
		{ name: 'colors',      items : [ 'TextColor','BGColor' ] },
		{ name: 'basicstyles', items : [ 'Bold','Italic','Strike','-','RemoveFormat' ] },
		{ name: 'paragraph', items : [ 'JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock', '-', 'NumberedList','BulletedList','-','Outdent','Indent','-','Blockquote' ] },
		{ name: 'links', items : [ 'Link','Unlink','Anchor' ] },
		{ name: 'tools', items : [ 'Maximize', 'ShowBlocks' ,'-','About' ] }
	];
};