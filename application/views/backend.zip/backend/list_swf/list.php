<!-- end::Body -->
<body class="m-page--fluid m--skin- m-content--skin-light2 m-header--fixed m-header--fixed-mobile m-aside-left--enabled m-aside-left--skin-dark m-aside-left--offcanvas m-footer--push m-aside--offcanvas-default"  >
   <!-- begin:: Page -->
   <div class="m-grid m-grid--hor m-grid--root m-page">
      <?php include VIEWS_PATH_BACKEND."/menu.php"; ?>
      <!-- begin::Body -->
      <div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">
         <?php include VIEWS_PATH_BACKEND."/leftMenu.php"; ?>	
         <div class="m-grid__item m-grid__item--fluid m-wrapper">
            <!-- BEGIN: Subheader -->
            <div class="m-subheader ">
               <div class="d-flex align-items-center">
                  <div class="mr-auto">
                     <h4 class="m-subheader__title m-subheader__title--separator">
                        <?php echo $breadcrump['module_group_name']; ?> - <?php echo $breadcrump['module_name']; ?> - 360
                     </h4>
                  </div>
               </div>
            </div>
            <?php if(isset($error)){ ?>
            <div class="panel-body">
               <div class="form-group has-error">
                  <label for="inputError" class="col-sm-2 control-label col-lg-2"><?php echo $error;?></label>
               </div>
            </div>
            <?php } ?>
            <!-- END: Subheader -->
            <div class="m-content">
               <div class="m-portlet m-portlet--mobile">
                  <div class="m-portlet__body">
                     <!--begin: Search Form -->
                     <div class="col-lg-12" id="frmadd">
                        <?php if($add){ ?>
                        <input class="btn btn-primary btn-sm" type="button" value="Add" onClick="javascript:showFormUpload()">
                        <?php } ?>
                     </div>
                     <div class="col-lg-12" id="frmUpload" style="display: none;">
                        <?php include 'vupload.php'; ?>
                     </div>
                     <!--end: Search Form -->
                  </div>
                  <div class="m-portlet m-portlet--mobile">
                     <div class="m-portlet__body">
                        <!--begin: Datatable -->
                        <section id="unseen">
                           <section id="unseen">
                              <?php include 'vsubpage_list.php'; ?>
                           </section>
                        </section>
                        <!--end: Datatable -->
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end:: Body -->
      <?php include VIEWS_PATH_BACKEND."/footer.php"; ?>
   </div>
   <!-- end:: Page -->
   <!--begin::Base Scripts -->
   <script src="<?php echo BACKEND_BASE_URL; ?>/vendors/base/vendors.bundle.js" type="text/javascript"></script>
   <script src="<?php echo BACKEND_BASE_URL; ?>/demo/default/base/scripts.bundle.js" type="text/javascript"></script>
   <!--end::Base Scripts -->   
   <!--begin::Page Vendors -->
   <script src="<?php echo BACKEND_BASE_URL; ?>/demo/default/custom/components/datatables/base/html-table.js" type="text/javascript"></script>
   <!--end::Page Snippets -->
   <script language="javascript">
      function showFormUpload(){
      $("#frmadd").hide(); 
      $("#frmUpload").show();
      } 
      function hideFormUpload(){
      $("#frmadd").show(); 
      $("#frmUpload").hide();
      }     
          
      function updateOrder(){
      var frm = document.formAssignment;
      var answer = confirm('are you sure want to update order?');
      
      if(answer){
      frm.action = '<?php echo BASE_URL_BACKEND;?>/Content_subpage/doOrder';
      frm.submit();
      } else {
      return false;
      }
      }
      
      
   </script>
</body>
<!-- end::Body -->
</html>