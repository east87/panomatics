<?php echo form_open_multipart(BASE_URL_BACKEND.'/'.$controller."/insertGallery", array('id' => 'upload-file-form'));?>
<input type="hidden" name="gallery_type" readonly="readonly" id="gallery_type" class="form-control" value="2">
      <div class="form-group m-form__group row">
         <label class="col-lg-2 col-form-label">
         Gallery Title:
         </label>
         <div class="col-lg-6">
            <input name="subpage_title[]" id="subpage_title1" type="text" class="form-control" placeholder="Gallery Title" value="">
         </div>
      </div>
      <div class="form-group m-form__group row">
         <label for="inputEmail1" class="col-lg-2 col-sm-2 control-label">Gallery Image</label>
         <div class="col-lg-4">
            <div style="margin-bottom:2px;" class="imageurl1"></div>
            <input type="text" name="subpage_image[]" readonly="readonly" id="imageurl1" class="form-control" value="">
            <p class="help-block">width and height optimal is  900x600 px</p>
            <div style="margin-right:50px;">
               <a class="btn btn-outline-brand m-btn m-btn--icon m-btn--icon-only m-btn--outline-2x" onClick="openKCFinder('imageurl1');" id="link-file" class="link" style="cursor:pointer;"><i class="flaticon-attachment"></i></a>
               <a class="btn btn-outline-brand m-btn m-btn--icon m-btn--icon-only m-btn--outline-2x" onClick="reset_value('imageurl1');" id="link-file" class="link"><i class="fa fa-refresh"></i></a>                                               
            </div>
         </div>
      </div>
      <div id="moreAccordion"></div>
      <div style="clear:both;"></div>
      <div id="moreAccordionLink" style="">
      </div>
      <script type="text/javascript">
         $(function() {
             var subpage_number = 2;
             $('#subpageMore').click(function() {
                 //add more file
                 var moreSubpageTag = '';
                
                         moreSubpageTag += '<div class="form-group m-form__group row">';
                                         moreSubpageTag += '<label for="inputsubpage" class="col-lg-2 col-sm-2 control-label">Gallery Title</label>';
                                         moreSubpageTag += '<div class="col-lg-8">';
                                         moreSubpageTag += '<input id="subpage_title' + subpage_number + '" name="subpage_title[]" type="text" class="form-control" placeholder="Gallery Title" value="">';
                                         moreSubpageTag += '</div>';
                                     moreSubpageTag += '</div>';
                         
                         moreSubpageTag += '<div class="form-group m-form__group row">';
                                         moreSubpageTag += '<label for="inputDescription" class="col-lg-2 col-sm-2 control-label">Gallery Image</label>';                            
                                         moreSubpageTag += '<div class="col-lg-10">';
                                         moreSubpageTag += '<div style="margin-bottom:2px;" class="imageurl' + subpage_number + '"></div>';
                                         moreSubpageTag += '<input type="text" name="subpage_image[]" readonly="readonly" id="imageurl' + subpage_number + '" class="form-control" value="">';
                                         moreSubpageTag += '<p class="help-block">width and height optimal is  900x600 px</p>';
                                         moreSubpageTag += '<div style="margin-right:50px;">';
                                         moreSubpageTag += '<a class="btn btn-outline-brand m-btn m-btn--icon m-btn--icon-only m-btn--outline-2x" onclick="openKCFinder(&#39;imageurl' + subpage_number + '&#39;);" id="link-file" class="link" style="cursor:pointer;"><i class="flaticon-attachment"></i> </a>';
                                         moreSubpageTag += '<a class="btn btn-outline-brand m-btn m-btn--icon m-btn--icon-only m-btn--outline-2x" onClick="reset_value(&#39;imageurl' + subpage_number + '&#39;);" id="link-file" class="link" style="cursor:pointer;"><i class="fa fa-refresh"></i></a>';                   
                                         moreSubpageTag += '</div>';                               
                                         moreSubpageTag += '</div>';
                                         moreSubpageTag += '<div class="m-form__group">';
                                         moreSubpageTag += '<div class="col-lg-12">';
                                         moreSubpageTag += '&nbsp;<a class="btn-danger btn-sm"  href="javascript:del_accordion(' + subpage_number + ')" style="cursor:pointer;" onclick="return confirm(\"Are you really want to delete ?\")"><span class="la la-trash"></span> ' + subpage_number + '</span></a>';                                                                                      
                                         moreSubpageTag += '</div>';
                                     moreSubpageTag += '</div>';         
                         
                       
                 
                 $('<dl id="delete_file' + subpage_number + '">' + moreSubpageTag + '</dl>').fadeIn('slow').appendTo('#moreAccordion');
                
                // CKEDITOR.enableAutoInline = true;
                //  CKEDITOR.inline( 'IDaccordescs' + subpage_number );
                 subpage_number++;
                
             });
             
             
              
         });
      </script>	
      <div class="form-group m-form__group row">  
         <a class="btn btn-submit btn-outline btn-primary" href="javascript:void(0);" id="subpageMore"><span> <i class="fa fa-plus"></i> <span></span></a>                       
         <input type="submit" name="file_upload" value="Upload" class="btn btn-submit btn-outline btn-primary"/>
         <input class="btn btn-primary btn-danger" type="button" value="Cancel" onClick="javascript:hideFormUpload()">
      </div>

<?php
   echo form_close();
   ?>
<script type="text/javascript">
   function del_accordion(eleId) {
       var ele = document.getElementById("delete_file" + eleId);
       ele.parentNode.removeChild(ele);
   }
</script>
<script type="text/javascript">
   $(document).ready(function() {
       $("input[id^='upload_file']").each(function() {
           var id = parseInt(this.id.replace("upload_file", ""));
           $("#upload_file" + id).change(function() {
               if ($("#upload_file" + id).val() !== "") {
                   $("#moreImageUploadLink").show();
               }
           });
       });
   });
</script>
<script language="javascript">
   function Confirm_hapus(){
   	if(confirm("KONFIRMASI PENGHAPUSAN DATA\nTekan OK untuk melanjutkan penghapusan data")==true){
   		return true;
   	}else{
   		return false;
   	}
   }
</script>