<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Headerweddings extends CI_Controller {

	public $arrMenu = array();
	public $data;
	public $privilege = array();
	public function __construct()

	{
		parent::__construct();

                if( ! $_SESSION)
                {
                    session_start();
                }

		if(empty($_SESSION['admin_data'])){
			session_destroy();
			redirect(BASE_URL_BACKEND."/signin");
			exit();

		}

		$this->load->model(array('backend/Model_menu_frontend','backend/Model_headerweddings','backend/Model_alias', 'backend/Model_language','backend/Model_logcms'));
		$this->load->helper(array('funcglobal','menu','accessprivilege','alias'));		
                $module_name=  $this->uri->segment(2);
                $getmodule = $this->Model_headerweddings->getModule($module_name);
                foreach ($getmodule as $gm) {
                 $this->module_id = $gm->module_id;
                 $this->section = $gm->module_group_id;
                 $_SESSION['module_id']=$this->module_id;
                }
		//get menu from helper menu
		//get menu from helper menu
		$this->arrMenu = menu();
		$this->data = array();
                $this->data['ListMenu'] = $this->arrMenu;
                $this->data['CountMenu'] = count($this->arrMenu);
		$this->data['controller'] = $module_name;
               

		//check privilege module

		$this->privilege = accessprivilegeuserlevel($_SESSION['admin_data']['user_level_id'], $_SESSION['module_id']);

		$this->breadcrump = breadCrump($_SESSION['module_id']);

	}

	public function index()
	{
		$this->view();
	}
	
	function view(){

		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $_SESSION['module_id'];
		$this->data['breadcrump'] = $this->breadcrump;
		$searchkey = "";
		$searchby = "";
             
                $condp = "order BY a.header_id";
                $ListHeaderweddings = $this->Model_headerweddings->getListHeaderweddings($condp);	
		$this->data["ListHeaderweddings"] = $ListHeaderweddings;
		//extract privilege
		$this->data["list"] = $this->privilege[0];
		$this->data["view"] = $this->privilege[1];
		$this->data["add"] = $this->privilege[2];
		$this->data["edit"] = $this->privilege[3];
		$this->data["publish"] = $this->privilege[4];
		$this->data["approve"] = $this->privilege[5];
		$this->data["delete"] = $this->privilege[6];
		$this->data["order"] = $this->privilege[7];
		if($this->data["list"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}		
		$this->data['searchkey'] = $searchkey;
		$this->data['searchby'] = $searchby;		
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/headerweddings/list');

	}

         function add(){

		//extract privilege

		$this->data["add"] = $this->privilege[2];
		if($this->data["add"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}		
                              
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
               
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/headerweddings/add',$this->data);
	}      

	public function doAdd(){

		//extract privilege
		$this->data["add"] = $this->privilege[2];
		if($this->data["add"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		$tb = $_POST['tbSave'];
		if (!$tb) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		}

		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		$header_title = $this->security->xss_clean(secure_input($_POST['headerweddingstitle'])); 
                $header_desc = $this->security->xss_clean(secure_input($_POST['headerweddingsdesc']));
                $header_video_url=$this->security->xss_clean(secure_input($_POST['headervideourl']));
		$pesan = array();
		// Validasi data
		if ($header_title=="") {
			$pesan[] = 'Headerweddings Page Title is empty';
		} 
	

		if (! count($pesan)==0 ) {

			foreach ($pesan as $indeks=>$pesan_tampil) {
				$this->data['error'] = $pesan_tampil;				
				$this->data['headerweddingstitle']=$header_title;
                                $this->data['headerweddingsdesc']=$header_desc;
                                $this->data['headervideourl']=$header_video_url;
									
				$this->load->view('backend/header',$this->data);
				$this->load->view('backend/headerweddings/add',$this->data);
			}
		} else {
			$cekHeaderweddings = $this->Model_headerweddings->checkHeaderweddings($header_title);
			$countHeaderweddings = count($cekHeaderweddings);
			
			if ($countHeaderweddings > 0 ) {

				$this->data['error']='Headerweddings Title '.$header_title.' already exist';
				$this->data['header_title']=$header_title;
			
				$this->load->view('backend/header',$this->data);

				$this->load->view('backend/headerweddings/add',$this->data);

			} else {

				$header_id = $this->Model_headerweddings->insertHeaderweddings($header_title,$header_desc,$header_video_url);

                                $log_module = "Add ".$this->module;
                                $log_value = $header_id." | ".$header_title;
                                $insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);				
                                redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
	
			}	
		}	
	}
   

	function active($id){

		if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();

		}
		//extract privilege

		$this->data["approve"] = $this->privilege[5];
		if($this->data["approve"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}
		$rsHeaderweddings = $this->Model_headerweddings->getHeaderweddings($id); 
		$title = $rsHeaderweddings[0]['header_title'];
		$active_status = abs($rsHeaderweddings[0]['header_active_status']-1);
		$active = $this->Model_headerweddings->activeHeaderweddings($id);

		createRouteAlias(); //create route alias
		if($active_status == 1){
			$log_module = "Active ".$this->data['controller'];
		} else {
			$log_module = "Inactive ".$this->data['controller'];
		}
		$log_value = $id." | ".$title." | ".$active_status;
		$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
                
                $this->generateHeaderweddings();
		redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);

	}

 
        function delete($id){

		if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();

		}
		//extract privilege

		$this->data["delete"] = $this->privilege[6];		
		if($this->data["delete"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}
		$rsHeaderweddings = $this->Model_headerweddings->getHeaderweddings($id); 
		$title = $rsHeaderweddings[0]['header_title'];       
               

                if($page_type == 2){
                $this->deleteHeaderweddings($id);

                }
                $delete = $this->Model_headerweddings->deleteHeaderweddings($id);
		$log_module = "Delete ".$this->module;
		$log_value = $id." | ".$title;
		$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
                
                $this->generateHeaderweddings();
		redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
	}
      

        public function deleteHeaderweddings($id){

            if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		}

		//extract privilege

		$this->data["delete"] = $this->privilege[6];
		if($this->data["delete"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}
                $where = "";
                $orderBy = "ORDER BY a.header_id DESC";		
		$cond 			= $where." ".$orderBy;
                $ListHeaderweddings = $this->Model_headerweddings->getListHeaderweddings($id, $cond);
                foreach($ListHeaderweddings as $headerweddings){  
                        $image_path = './assets/images/'.$headerweddings['header_image']; 
                        $image_resize = './assets/images/resized/'.$headerweddings['header_image'];         
                        $image_thumb = './assets/images/thumb/'.$headerweddings['header_image']; 
                        if($headerweddings['header_image'] != 'default_icon.png'){
                        unlink($image_path);
                        unlink($image_resize);
                        unlink($image_thumb);
                           }     
                        $this->Model_headerweddings->deleteHeaderweddings($headerweddings['header_id']);

                }                   

        }


      public function edit($id){

		if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);

			exit();

		}

		//extract privilege

		$this->data["edit"] = $this->privilege[3];
		if($this->data["edit"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}

		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;	

		$rsHeaderweddings = $this->Model_headerweddings->getHeaderweddings($id); 
                // mengambil database dari model untuk dikirim ke view		
                $countHeaderweddings = count($rsHeaderweddings);
		$this->data['rsHeaderweddings'] = $rsHeaderweddings;
		$this->data['countHeaderweddings'] = $countHeaderweddings;
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/headerweddings/edit',$this->data);

	}

	

	public function doEdit($id){

		$tb = $_POST['tbEdit'];
		if (!$tb OR $id == '') {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();

		}

		//extract privilege

		$this->data["edit"] = $this->privilege[3];
		if($this->data["edit"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		$rsHeaderweddings = $this->Model_headerweddings->getHeaderweddings($id);  // mengambil database dari model untuk dikirim ke view
		$countHeaderweddings = count($rsHeaderweddings);
		$this->data['rsHeaderweddings'] = $rsHeaderweddings;
		$this->data['countHeaderweddings'] = $countHeaderweddings;
		$header_title = $this->security->xss_clean(secure_input($_POST['headerweddingstitle']));
                $header_titleOld = $this->security->xss_clean(secure_input($_POST['header_titleOld']));
                $header_desc = $this->security->xss_clean(secure_input($_POST['headerweddingsdesc']));
                $header_video_url=$this->security->xss_clean(secure_input($_POST['headervideourl']));
                
		$pesan = array();
		// Validasi data
		if ($header_title=="") {
			$pesan[] = 'Headerweddings Title is empty';
		} 
		if (! count($pesan)==0 ) {
			foreach ($pesan as $indeks=>$pesan_tampil) {
				$this->data['error'] = $pesan_tampil;
				$this->load->view('backend/header',$this->data);
				$this->load->view('backend/headerweddings/edit',$this->data);
			}
		} else {
                      
				$update = $this->Model_headerweddings->updateHeaderweddings($id,$header_title,$header_desc,$header_video_url);				
                                $log_module = "Edit ".$this->module;
                                $log_value = $id." | ".$header_title;
                                $insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);                                
                                $this->generateHeaderweddings();
                        redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);	
		}		
	}  
       

        function doOrder(){
		$order = $this->security->xss_clean($_POST['order']);
		if($order == ""){
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		} 

        foreach($order as $id => $ordervalue){
			$this->Model_headerweddings->updateOrderHeaderweddings($id,$ordervalue);
                        echo $ordervalue;
		}
                $this->generateHeaderweddings();
		redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);

	}
 
      function generateHeaderweddings(){
                $ListHeaderweddings		= $this->Model_headerweddings->generateHeaderweddings(" where a.header_active_status=1");
		$countHeaderweddings		= count($ListHeaderweddings);
		//createCacheBanner($rsBanner,"bannerhome");
               createCache($ListHeaderweddings,"headerweddings");
        }  
 
    public function resizing($resize) {
        $imageurl = str_replace(BASE_URL,PATH_PROJECT,$resize);
        $image_name = end((explode('/', $resize)));
       // echo PATH_PROJECT.$image_name;
        
        $config['image_library'] = 'gd2';
        $config['source_image'] = $imageurl;
        $config['new_image'] = PATH_ASSETS.'/file_upload/thumbs/'.$image_name;
        
        $config['create_thumb'] = FALSE;
        $config['maintain_ratio'] = FALSE;
        $config['width']         = 350;
        $config['height']       = 300;
        $config['x_axis']         = 150;
        $config['y_axis']       = 150;
        $this->load->library('image_lib', $config);
        $this->image_lib->resize();
        //$this->image_lib->crop();
       
    }
    
}