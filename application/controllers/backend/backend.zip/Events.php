<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Events extends CI_Controller {

	public $arrMenu = array();
	public $data;
	public $privilege = array();
	public function __construct()

	{
		parent::__construct();

                if( ! $_SESSION)
                {
                    session_start();
                }

		if(empty($_SESSION['admin_data'])){
			session_destroy();
			redirect(BASE_URL_BACKEND."/signin");
			exit();

		}

		$this->load->model(array('backend/Model_menu_frontend','backend/Model_events','backend/Model_alias', 'backend/Model_language','backend/Model_logcms'));
		$this->load->helper(array('funcglobal','menu','accessprivilege','alias'));		
                $module_name=  $this->uri->segment(2);
                $getmodule = $this->Model_events->getModule($module_name);
                foreach ($getmodule as $gm) {
                 $this->module_id = $gm->module_id;
                 $this->section = $gm->module_group_id;
                 $_SESSION['module_id']=$this->module_id;
                }
                $this->module=$module_name;
		//get menu from helper menu
		//get menu from helper menu
		$this->arrMenu = menu();
		$this->data = array();
                $this->data['ListMenu'] = $this->arrMenu;
                $this->data['CountMenu'] = count($this->arrMenu);
		$this->data['controller'] = $module_name;
               

		//check privilege module

		$this->privilege = accessprivilegeuserlevel($_SESSION['admin_data']['user_level_id'], $_SESSION['module_id']);

		$this->breadcrump = breadCrump($_SESSION['module_id']);

	}

	public function index()
	{
		$this->view();
	}
	
	function view(){

		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $_SESSION['module_id'];
		$this->data['breadcrump'] = $this->breadcrump;
		$searchkey = "";
		$searchby = "";
             
                $condp = "order BY a.events_id";
                $ListEvents = $this->Model_events->getListEvents($condp);	
		$this->data["ListEvents"] = $ListEvents;
		//extract privilege
		$this->data["list"] = $this->privilege[0];
		$this->data["view"] = $this->privilege[1];
		$this->data["add"] = $this->privilege[2];
		$this->data["edit"] = $this->privilege[3];
		$this->data["publish"] = $this->privilege[4];
		$this->data["approve"] = $this->privilege[5];
		$this->data["delete"] = $this->privilege[6];
		$this->data["order"] = $this->privilege[7];
		if($this->data["list"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}		
		$this->data['searchkey'] = $searchkey;
		$this->data['searchby'] = $searchby;		
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/events/list');

	}

         function add(){

		//extract privilege

		$this->data["add"] = $this->privilege[2];
		if($this->data["add"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}		
                              
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
               
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/events/add',$this->data);
	}      

	public function doAdd(){

		//extract privilege
		$this->data["add"] = $this->privilege[2];
		if($this->data["add"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		$tb = $_POST['tbSave'];
		if (!$tb) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		}

		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		$events_title = $this->security->xss_clean(secure_input($_POST['eventstitle'])); 
                $events_imageurl = $this->security->xss_clean(secure_input($_POST['eventsimageurl']));
		$events_desc = $this->security->xss_clean(secure_input($_POST['eventsdesc']));		
		$pesan = array();
		// Validasi data
		if ($events_title=="") {
			$pesan[] = 'Events Page Title is empty';
		} 
	

		if (! count($pesan)==0 ) {

			foreach ($pesan as $indeks=>$pesan_tampil) {
				$this->data['error'] = $pesan_tampil;				
				$this->data['eventstitle']=$events_title;
                                $this->data['eventsdesc']=$events_desc;
                                $this->data['eventsimageurl']=$events_imageurl;					
				$this->load->view('backend/header',$this->data);
				$this->load->view('backend/events/add',$this->data);
			}
		} else {
			$cekEvents = $this->Model_events->checkEvents($events_title);
			$countEvents = count($cekEvents);
			
			if ($countEvents > 0 ) {

				$this->data['error']='Events Title '.$events_title.' already exist';
				$this->data['events_title']=$events_title;
                                $this->data['eventsdesc']=$events_desc;
                                $this->data['eventsimageurl']=$events_imageurl;
				$this->load->view('backend/header',$this->data);

				$this->load->view('backend/events/add',$this->data);

			} else {

				$events_imageurl = str_replace(BASE_URL,"",$events_imageurl);
				$events_id = $this->Model_events->insertEvents($events_title,$events_imageurl,$events_desc);

					$log_module = "Add ".$this->module;
					$log_value = $events_id." | ".$events_title;
					$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);				
					redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
	
			}	
		}	
	}
   

	function active($id){

		if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();

		}
		//extract privilege

		$this->data["approve"] = $this->privilege[5];
		if($this->data["approve"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}
		$rsEvents = $this->Model_events->getEvents($id); 
		$title = $rsEvents[0]['events_title'];
		$active_status = abs($rsEvents[0]['events_active_status']-1);
		$active = $this->Model_events->activeEvents($id);

		createRouteAlias(); //create route alias
		if($active_status == 1){
			$log_module = "Active ".$this->module;
		} else {
			$log_module = "Inactive ".$this->module;
		}
		$log_value = $id." | ".$title." | ".$active_status;
		$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
                
                $this->generateEvents();
		redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);

	}

 
        function delete($id){

		if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();

		}
		//extract privilege

		$this->data["delete"] = $this->privilege[6];		
		if($this->data["delete"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}
		$rsEvents = $this->Model_events->getEvents($id); 
		$title = $rsEvents[0]['events_title'];       
               

                if($page_type == 2){
                $this->deleteEvents($id);

                }
                $delete = $this->Model_events->deleteEvents($id);
		$log_module = "Delete ".$this->module;
		$log_value = $id." | ".$title;
		$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
                
                $this->generateEvents();
		redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
	}
      

        public function deleteEvents($id){

            if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		}

		//extract privilege

		$this->data["delete"] = $this->privilege[6];
		if($this->data["delete"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}
                $where = "";
                $orderBy = "ORDER BY a.events_id DESC";		
		$cond 			= $where." ".$orderBy;
                $ListEvents = $this->Model_events->getListEvents($id, $cond);
                foreach($ListEvents as $events){  
                        $image_path = './assets/images/'.$events['events_image']; 
                        $image_resize = './assets/images/resized/'.$events['events_image'];         
                        $image_thumb = './assets/images/thumb/'.$events['events_image']; 
                        if($events['events_image'] != 'default_icon.png'){
                        unlink($image_path);
                        unlink($image_resize);
                        unlink($image_thumb);
                           }     
                        $this->Model_events->deleteEvents($events['events_id']);

                }                   

        }


      public function edit($id){

		if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);

			exit();

		}

		//extract privilege

		$this->data["edit"] = $this->privilege[3];
		if($this->data["edit"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}

		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;	

		$rsEvents = $this->Model_events->getEvents($id); 
                // mengambil database dari model untuk dikirim ke view		
                $countEvents = count($rsEvents);
		$this->data['rsEvents'] = $rsEvents;
		$this->data['countEvents'] = $countEvents;
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/events/edit',$this->data);

	}

	

	public function doEdit($id){

		$tb = $_POST['tbEdit'];
		if (!$tb OR $id == '') {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();

		}

		//extract privilege

		$this->data["edit"] = $this->privilege[3];
		if($this->data["edit"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		$rsEvents = $this->Model_events->getEvents($id);  // mengambil database dari model untuk dikirim ke view
		$countEvents = count($rsEvents);
		$this->data['rsEvents'] = $rsEvents;
		$this->data['countEvents'] = $countEvents;
		$events_title = $this->security->xss_clean(secure_input($_POST['eventstitle']));
                $events_titleOld = $this->security->xss_clean(secure_input($_POST['events_titleOld']));
                $events_imageurl = $this->security->xss_clean(secure_input($_POST['eventsimageurl']));
                $events_desc = $this->security->xss_clean(secure_input($_POST['eventsdesc']));	
		
		$pesan = array();
		// Validasi data
		if ($events_title=="") {
			$pesan[] = 'Events Title is empty';
		} 
		if (! count($pesan)==0 ) {
			foreach ($pesan as $indeks=>$pesan_tampil) {
				$this->data['error'] = $pesan_tampil;
				$this->load->view('backend/header',$this->data);
				$this->load->view('backend/events/edit',$this->data);
			}
		} else {
                                $events_imageurl = str_replace(BASE_URL,"",$events_imageurl);
				$update = $this->Model_events->updateEvents($id,$events_title,$events_imageurl,$events_desc);				
                                $log_module = "Edit ".$this->module;
                                $log_value = $id." | ".$events_title;
                                $insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
                                
                                $this->generateEvents();                                    
                                redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
                }		
	}  
       

        function doOrder(){
		$order = $this->security->xss_clean($_POST['order']);
		if($order == ""){
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		} 

        foreach($order as $id => $ordervalue){
			$this->Model_events->updateOrderEvents($id,$ordervalue);
                        echo $ordervalue;
		}
                $this->generateEvents();
		redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);

	}


 
      function generateEvents(){
                $ListEvents		= $this->Model_events->generateEvents(" where a.events_active_status=1 order by events_order ASC");
		$countEvents		= count($ListEvents);
		//createCacheBanner($rsBanner,"bannerhome");
               createCache($ListEvents,"events");
        }  
 
    public function resizing($resize) {
        $imageurl = str_replace(BASE_URL,PATH_PROJECT,$resize);
        $image_name = end((explode('/', $resize)));
       // echo PATH_PROJECT.$image_name;
        
        $config['image_library'] = 'gd2';
        $config['source_image'] = $imageurl;
        $config['new_image'] = PATH_ASSETS.'/file_upload/thumbs/'.$image_name;
        
        $config['create_thumb'] = FALSE;
        $config['maintain_ratio'] = FALSE;
        $config['width']         = 350;
        $config['height']       = 300;
        $config['x_axis']         = 150;
        $config['y_axis']       = 150;
        $this->load->library('image_lib', $config);
        $this->image_lib->resize();
        //$this->image_lib->crop();
       
    }
    
}