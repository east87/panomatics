<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ocean extends CI_Controller {

	public $arrMenu = array();
	public $data;
	public $privilege = array();
	public function __construct()

	{
		parent::__construct();

                if( ! $_SESSION)
                {
                    session_start();
                }

		if(empty($_SESSION['admin_data'])){
			session_destroy();
			redirect(BASE_URL_BACKEND."/signin");
			exit();

		}

		$this->load->model(array('backend/Model_menu_frontend','backend/Model_ocean','backend/Model_alias', 'backend/Model_language','backend/Model_logcms'));
		$this->load->helper(array('funcglobal','menu','accessprivilege','alias'));		
                $module_name=  $this->uri->segment(2);
                $getmodule = $this->Model_ocean->getModule($module_name);
                foreach ($getmodule as $gm) {
                 $this->module_id = $gm->module_id;
                 $this->section = $gm->module_group_id;
                 $_SESSION['module_id']=$this->module_id;
                }
		//get menu from helper menu
		//get menu from helper menu
		$this->arrMenu = menu();
		$this->data = array();
                $this->data['ListMenu'] = $this->arrMenu;
                $this->data['CountMenu'] = count($this->arrMenu);
		$this->data['controller'] = $module_name;
               

		//check privilege module

		$this->privilege = accessprivilegeuserlevel($_SESSION['admin_data']['user_level_id'], $_SESSION['module_id']);

		$this->breadcrump = breadCrump($_SESSION['module_id']);

	}

	public function index()
	{
		$this->view();
	}
	
	function view(){

		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $_SESSION['module_id'];
		$this->data['breadcrump'] = $this->breadcrump;
		$searchkey = "";
		$searchby = "";
             
                $condp = "order BY a.ocean_order";
                $ListOcean = $this->Model_ocean->getListOcean($condp);	
		$this->data["ListOcean"] = $ListOcean;
		//extract privilege
		$this->data["list"] = $this->privilege[0];
		$this->data["view"] = $this->privilege[1];
		$this->data["add"] = $this->privilege[2];
		$this->data["edit"] = $this->privilege[3];
		$this->data["publish"] = $this->privilege[4];
		$this->data["approve"] = $this->privilege[5];
		$this->data["delete"] = $this->privilege[6];
		$this->data["order"] = $this->privilege[7];
		if($this->data["list"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}		
		$this->data['searchkey'] = $searchkey;
		$this->data['searchby'] = $searchby;		
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/ocean/list');

	}

         function add(){

		//extract privilege

		$this->data["add"] = $this->privilege[2];
		if($this->data["add"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}		
                              
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
               
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/ocean/add',$this->data);
	}      

	public function doAdd(){

		//extract privilege
		$this->data["add"] = $this->privilege[2];
		if($this->data["add"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		$tb = $_POST['tbSave'];
		if (!$tb) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		}

		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		$ocean_title = $this->security->xss_clean(secure_input($_POST['oceantitle']));
                $ocean_name = $this->security->xss_clean(secure_input($_POST['oceanname'])); 
                $ocean_imageurl = $this->security->xss_clean(secure_input($_POST['oceanimageurl']));
		$ocean_desc = $this->security->xss_clean(secure_input($_POST['oceandesc']));
                $ocean_urla = $this->security->xss_clean(secure_input($_POST['oceanurla'])); 
                $ocean_urlb = $this->security->xss_clean(secure_input($_POST['oceanurlb'])); 
               
		$pesan = array();
		// Validasi data
		if ($ocean_title=="") {
			$pesan[] = 'Ocean Page Title is empty';
		} 
	

		if (! count($pesan)==0 ) {

			foreach ($pesan as $indeks=>$pesan_tampil) {
				$this->data['error'] = $pesan_tampil;				
				$this->data['oceantitle']=$ocean_title;
                                $this->data['oceanname']=$ocean_name;
                                $this->data['oceandesc']=$ocean_desc;
                                $this->data['oceanimageurl']=$ocean_imageurl;
                                $this->data['oceanurla']=$ocean_urla;
                                $this->data['oceanurlb']=$ocean_urlb;
                               
									
				$this->load->view('backend/header',$this->data);
				$this->load->view('backend/ocean/add',$this->data);
			}
		} else {
			$cekOcean = $this->Model_ocean->checkOcean($ocean_title);
			$countOcean = count($cekOcean);
			
			if ($countOcean > 0 ) {

				$this->data['error']='Ocean Title '.$ocean_title.' already exist';
				$this->data['ocean_title']=$ocean_title;
			
				$this->load->view('backend/header',$this->data);

				$this->load->view('backend/ocean/add',$this->data);

			} else {

				$ocean_imageurl = str_replace(BASE_URL,"",$ocean_imageurl);
				$ocean_id = $this->Model_ocean->insertOcean($ocean_title,$ocean_name, $ocean_imageurl,$ocean_desc,$ocean_urla,$ocean_urlb);

                                
					$log_module = "Add ".$this->module;
					$log_value = $ocean_id." | ".$ocean_title;
					$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);				
					redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
	
			}	
		}	
	}
   

	function active($id){

		if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();

		}
		//extract privilege

		$this->data["approve"] = $this->privilege[5];
		if($this->data["approve"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}
		$rsOcean = $this->Model_ocean->getOcean($id); 
		$title = $rsOcean[0]['ocean_title'];
		$active_status = abs($rsOcean[0]['ocean_active_status']-1);
		$active = $this->Model_ocean->activeOcean($id);

		createRouteAlias(); //create route alias
		if($active_status == 1){
			$log_module = "Active ".$this->data['controller'];
		} else {
			$log_module = "Inactive ".$this->data['controller'];
		}
		$log_value = $id." | ".$title." | ".$active_status;
		$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
                
                $this->generateOcean();
		redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);

	}

 
        function delete($id){

		if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();

		}
		//extract privilege

		$this->data["delete"] = $this->privilege[6];		
		if($this->data["delete"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}
		$rsOcean = $this->Model_ocean->getOcean($id); 
		$title = $rsOcean[0]['ocean_title'];       
               

                if($page_type == 2){
                $this->deleteOcean($id);

                }
                $delete = $this->Model_ocean->deleteOcean($id);
		$log_module = "Delete ".$this->module;
		$log_value = $id." | ".$title;
		$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
                
                $this->generateOcean();
		redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
	}
      

        public function deleteOcean($id){

            if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		}

		//extract privilege

		$this->data["delete"] = $this->privilege[6];
		if($this->data["delete"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}
                $where = "";
                $orderBy = "ORDER BY a.ocean_id DESC";		
		$cond 			= $where." ".$orderBy;
                $ListOcean = $this->Model_ocean->getListOcean($id, $cond);
                foreach($ListOcean as $ocean){  
                        $image_path = './assets/images/'.$ocean['ocean_image']; 
                        $image_resize = './assets/images/resized/'.$ocean['ocean_image'];         
                        $image_thumb = './assets/images/thumb/'.$ocean['ocean_image']; 
                        if($ocean['ocean_image'] != 'default_icon.png'){
                        unlink($image_path);
                        unlink($image_resize);
                        unlink($image_thumb);
                           }     
                        $this->Model_ocean->deleteOcean($ocean['ocean_id']);

                }                   
            $this->generateOcean();
        }


      public function edit($id){

		if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);

			exit();

		}

		//extract privilege

		$this->data["edit"] = $this->privilege[3];
		if($this->data["edit"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;

		}

		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;	

		$rsOcean = $this->Model_ocean->getOcean($id); 
                // mengambil database dari model untuk dikirim ke view		
                $countOcean = count($rsOcean);
		$this->data['rsOcean'] = $rsOcean;
		$this->data['countOcean'] = $countOcean;
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/ocean/edit',$this->data);

	}

	

	public function doEdit($id){

		$tb = $_POST['tbEdit'];
		if (!$tb OR $id == '') {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();

		}

		//extract privilege

		$this->data["edit"] = $this->privilege[3];
		if($this->data["edit"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		$rsOcean = $this->Model_ocean->getOcean($id);  // mengambil database dari model untuk dikirim ke view
		$countOcean = count($rsOcean);
		$this->data['rsOcean'] = $rsOcean;
		$this->data['countOcean'] = $countOcean;
		$ocean_title = $this->security->xss_clean(secure_input($_POST['oceantitle']));
                $ocean_titleOld = $this->security->xss_clean(secure_input($_POST['ocean_titleOld']));
                $ocean_name = $this->security->xss_clean(secure_input($_POST['oceanname'])); 
                $ocean_imageurl = $this->security->xss_clean(secure_input($_POST['oceanimageurl']));
		$ocean_desc = $this->security->xss_clean(secure_input($_POST['oceandesc']));
                $ocean_urla = $this->security->xss_clean(secure_input($_POST['oceanurla'])); 
                $ocean_urlb = $this->security->xss_clean(secure_input($_POST['oceanurlb'])); 
		
		$pesan = array();
		// Validasi data
		if ($ocean_title=="") {
			$pesan[] = 'Ocean Title is empty';
		} 
		if (! count($pesan)==0 ) {
			foreach ($pesan as $indeks=>$pesan_tampil) {
				$this->data['error'] = $pesan_tampil;
				$this->load->view('backend/header',$this->data);
				$this->load->view('backend/ocean/edit',$this->data);
			}
		} else {

			$ocean_imageurl = str_replace(BASE_URL,"",$ocean_imageurl);
				$update = $this->Model_ocean->updateOcean($id,$ocean_title,$ocean_name,$ocean_imageurl,$ocean_desc,$ocean_urla,$ocean_urlb);				
                                $log_module = "Edit ".$this->module;
                                $log_value = $id." | ".$ocean_title;
                                $insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
                                
                                $this->generateOcean();         
                                redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);	
		}		
	}  
       

        function doOrder(){
		$order = $this->security->xss_clean($_POST['order']);
		if($order == ""){
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		} 

        foreach($order as $id => $ordervalue){
			$this->Model_ocean->updateOrderOcean($id,$ordervalue);
                        echo $ordervalue;
		}
                $this->generateOcean();
		redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);

	}

 
 
      function generateOcean(){
                $ListOcean		= $this->Model_ocean->generateOcean(" where a.ocean_active_status=1 order by ocean_order ASC");
		$countOcean		= count($ListOcean);
		//createCacheBanner($rsBanner,"bannerhome");
               createCache($ListOcean,"ocean");
        }  
 
    public function resizing($resize) {
        $imageurl = str_replace(BASE_URL,PATH_PROJECT,$resize);
        $image_name = end((explode('/', $resize)));
       // echo PATH_PROJECT.$image_name;
        
        $config['image_library'] = 'gd2';
        $config['source_image'] = $imageurl;
        $config['new_image'] = PATH_ASSETS.'/file_upload/thumbs/'.$image_name;
        
        $config['create_thumb'] = FALSE;
        $config['maintain_ratio'] = FALSE;
        $config['width']         = 350;
        $config['height']       = 300;
        $config['x_axis']         = 150;
        $config['y_axis']       = 150;
        $this->load->library('image_lib', $config);
        $this->image_lib->resize();
        //$this->image_lib->crop();
       
    }
    
}