<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bannerevent extends CI_Controller {
	public $arrMenu = array();
	public $data;
	public $privilege = array();
	public $section = 11; //get module group id from database
	public $module_id = 43; //get module id from database
	public $module = "Bannerevent";
	
	public function __construct()
	{
		parent::__construct();
                if( ! $_SESSION)
                {
                    session_start();
                }
		if(empty($_SESSION['admin_data'])){
			session_destroy();
			redirect(BASE_URL_BACKEND."/signin");
			exit();
		}
		
		$this->load->model(array('backend/Model_bannerevent','backend/Model_logcms'));
		$this->load->helper(array('funcglobal','menu','accessprivilege'));
		
		//get menu from helper menu
		$this->arrMenu = menu();
		$this->data = array();
                $this->data['ListMenu'] = $this->arrMenu;
                $this->data['CountMenu'] = count($this->arrMenu);
		
		
		//check privilege module
		$this->privilege = accessprivilegeuserlevel($_SESSION['admin_data']['user_level_id'], $this->module_id);
		$this->breadcrump = breadCrump($this->module_id);
	}
	
	public function index()
	{
		$this->view();
	}
	

	function view(){
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		
		
		
		$cond = "ORDER BY banner_order ASC";
		
		
		$this->data["ListBanner"] = $this->Model_bannerevent->getListBanner($cond);
		
                //print_r($this->data["ListBanner"]);
               // die;
		//extract privilege
		$this->data["list"] = $this->privilege[0];
		$this->data["view"] = $this->privilege[1];
		$this->data["add"] = $this->privilege[2];
		$this->data["edit"] = $this->privilege[3];
		$this->data["publish"] = $this->privilege[4];
		$this->data["approve"] = $this->privilege[5];
		$this->data["delete"] = $this->privilege[6];
		$this->data["order"] = $this->privilege[7];
		
		if($this->data["list"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		
		
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/bannerevent/list');
	}
	
	public function add(){
		//extract privilege
		$this->data["add"] = $this->privilege[2];
		
		if($this->data["add"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/bannerevent/add',$this->data);
	}
	
	public function doAdd(){
		//extract privilege
		$this->data["add"] = $this->privilege[2];
		
		if($this->data["add"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$tb = $_POST['tbSave'];
		if (!$tb) {
			redirect(BASE_URL_BACKEND."/bannerevent");
			exit();
		}
		
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		
		$bannername = $this->security->xss_clean(secure_input($_POST['bannername']));
		$bannersimageurl = $this->security->xss_clean(secure_input($_POST['bannersimageurl']));
                $bannerdesc = $this->security->xss_clean(secure_input(@$_POST['bannerdesc']));
		
		$pesan = array();
		// Validasi data
		 if ($bannersimageurl=="") {
			$pesan[] = 'Banner Image is empty';
		}
		
		if (! count($pesan)==0 ) {
			foreach ($pesan as $indeks=>$pesan_tampil) {
				$this->data['error'] = $pesan_tampil;
				
				$this->data['bannername']=$bannername;
				$this->data['bannertype']=$bannertype;
				$this->data['bannersimageurl']=$bannersimageurl;
				$this->data['bannerurl']=$bannerurl;
				
				$this->load->view('backend/header',$this->data);
				$this->load->view('backend/bannerevent/add',$this->data);
			}
		} else {
			$bannersimageurl = str_replace(BASE_URL,"",$bannersimageurl);
			$bannerid = $this->Model_bannerevent->insertBanner($bannername,$bannersimageurl,$bannerdesc);
			
			$log_module = "Add ".$this->module;
			$log_value = $bannerid." | ".$bannername." | ".$bannersimageurl." | ".$bannertype." | ".$bannerurl;
			$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
			
			redirect(BASE_URL_BACKEND."/bannerevent/");
		}	
	}
	
	function active($id){
		if (empty($id)) {
			redirect(BASE_URL_BACKEND."/bannerevent");
			exit();
		}
		
		//extract privilege
		$this->data["approve"] = $this->privilege[5];
		
		if($this->data["approve"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$rsBanner = $this->Model_bannerevent->getBanner($id); 
		$title = $rsBanner[0]['banner_name'];
		$active_status = abs($rsBanner[0]['banner_active_status']-1);
		
		$active = $this->Model_bannerevent->activeBanner($id);
		
		if($active_status == 1){
			$log_module = "Active ".$this->module;
		} else {
			$log_module = "Inactive ".$this->module;
		}
		$log_value = $id." | ".$title." | ".$active_status;
		$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
		
		//Cache JSON Meta
		$rsBanner			= $this->Model_bannerevent->getListBanner(" WHERE banner_active_status = 1 ORDER BY banner_order ASC ");
		$countBanner		= count($rsBanner);
		//createCacheBanner($rsBanner,"bannerevent");
                createCache($rsBanner,"bannerevent");
		//End Cache JSON Meta 
		
		redirect(BASE_URL_BACKEND."/bannerevent");
	}
	
	function delete($id){
		if (empty($id)) {
			redirect(BASE_URL_BACKEND."/bannerevent");
			exit();
		}
		
		//extract privilege
		$this->data["delete"] = $this->privilege[6];
		
		if($this->data["delete"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$rsBanner = $this->Model_bannerevent->getBanner($id); 
		$title = $rsBanner[0]['banner_name'];
		
		$delete = $this->Model_bannerevent->deleteBanner($id);
		
		$log_module = "Delete ".$this->module;
		$log_value = $id." | ".$title;
		$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
		
		//Cache JSON Meta
		$rsBanner			= $this->Model_bannerevent->getListBanner(" WHERE banner_active_status = 1 ORDER BY banner_order ASC ");
		$countBanner		= count($rsBanner);
		//createCacheBanner($rsBanner,"bannerevent");
                createCache($rsBanner,"bannerevent");
		//End Cache JSON Meta 
		
		redirect(BASE_URL_BACKEND."/bannerevent");
	}
	
	public function edit($id){
		if (empty($id)) {
			redirect(BASE_URL_BACKEND."/bannerevent");
			exit();
		}

		//extract privilege
		$this->data["edit"] = $this->privilege[3];
		
		if($this->data["edit"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		
		$rsBanner = $this->Model_bannerevent->getBanner($id);  // mengambil database dari model untuk dikirim ke view
		$countBanner = count($rsBanner);
		
		$this->data['rsBanner'] = $rsBanner;
		$this->data['countBanner'] = $countBanner;
		
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/bannerevent/edit',$this->data);
	}
	
	public function doEdit($id){
		$tb = $_POST['tbEdit'];
		if (!$tb OR $id == '') {
			redirect(BASE_URL_BACKEND."/bannerevent");
			exit();
		}
		
		//extract privilege
		$this->data["edit"] = $this->privilege[3];
		
		if($this->data["edit"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		
		$rsBanner = $this->Model_bannerevent->getBanner($id);  // mengambil database dari model untuk dikirim ke view
		$countBanner = count($rsBanner);
		
		$this->data['rsBanner'] = $rsBanner;
		$this->data['countBanner'] = $countBanner;
		
		$bannername = $this->security->xss_clean(secure_input($_POST['bannername']));
		$bannernameOld = $this->security->xss_clean(secure_input($_POST['bannernameOld']));
		
		$bannersimageurl = $this->security->xss_clean(secure_input($_POST['bannersimageurl']));
                $banner_status = $this->security->xss_clean(secure_input($_POST['bannerstatus']));
                $bannerdesc = $this->security->xss_clean(secure_input(@$_POST['bannerdesc']));
		if ($_SESSION['admin_data']['user_level_id'] == 1){
                    $banner_status = $banner_status;
                } else {
                     $banner_status = 0;
                }
		
		
		$pesan = array();
		if ($bannersimageurl=="") {
			$pesan[] = 'Banner Image is empty';
		} 
		
		
		if (! count($pesan)==0 ) {
			foreach ($pesan as $indeks=>$pesan_tampil) {
				$this->data['error'] = $pesan_tampil;
				
				$this->data['bannername']=$bannername;
				$this->data['bannersimageurl']=$bannersimageurl;
				
				$this->load->view('backend/header',$this->data);
				$this->load->view('backend/bannerevent/edit',$this->data);
			}
		} else {
			$bannersimageurl = str_replace(BASE_URL,"",$bannersimageurl);
			$update = $this->Model_bannerevent->updateBanner($id,$bannername,$bannersimageurl,$bannertype,$bannerurl,$bannerdesc,$banner_status);
			
			$log_module = "Edit ".$this->module;
			$log_value = $id." | ".$bannername." | ".$bannersimageurl." | ".$bannertype." | ".$bannerurl;
			$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
			
			//Cache JSON Meta
			$rsBanner			= $this->Model_bannerevent->getListBanner(" WHERE banner_active_status = 1 ORDER BY banner_order ASC ");
			$countBanner		= count($rsBanner);
			createCache($rsBanner,"bannerevent");
			//End Cache JSON Meta 
			
			redirect(BASE_URL_BACKEND."/bannerevent/");	
		}
		
	}
        public function doOrder(){
		
		$order = $this->security->xss_clean($_POST['order']);
		
		if($order == ""){
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		} 
		
		foreach($order as $id => $ordervalue){
			$this->Model_bannerevent->updateOrderBanner($id,$ordervalue);
                        echo $ordervalue;
		}
		$rsBanner			= $this->Model_bannerevent->getListBanner(" WHERE banner_active_status = 1 ORDER BY banner_order ASC ");
		$countBanner		= count($rsBanner);
		//createCacheBanner($rsBanner,"bannerevent");
                createCache($rsBanner,"bannerevent");
		redirect(BASE_URL_BACKEND."/bannerevent/");
	}
        
          function sendmailnotif($content_title, $controller, $log)  
            {     
       //  $this->load->library('email'); 
                        $subject = $log .'Banner Log';
                        $message_email = "Some one has been edit, <br><br>";
                        $message_email .= "Title : ".$content_title."<br>";
                        $message_email .= "Page : ".$controller."<br>";
			$header = "";
			$header .= "Reply-To: ".BASE_URL." <noreply@".$_SERVER['SERVER_NAME'].">\r\n";
			$header .= "Return-Path: ".BASE_URL." <noreply@".$_SERVER['SERVER_NAME'].">\r\n";
			$header .= "From: ".BASE_URL." <noreply@".$_SERVER['SERVER_NAME'].">\r\n";
			$header .= "Organization: ".$_SERVER['SERVER_NAME']." \r\n";
			$header .= "X-Priority: 3\r\n";
			$header .= "MIME-Version: 1.0\r\n";
			$header .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
              
                       
                // Insert user record     
                 mail(MAIL_ADMINISTRATOR, $subject, $message_email, $header);   
                // mail("hl.prbadolsa@gmail.com", $subject, $message_email, $header);  
            } 
}