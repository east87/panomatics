<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Blog extends CI_Controller {
	public $arrMenu = array();
	public $data;
	public $privilege = array();
//	public $section = 8; //get module group id from database
//	public $module_id = 15; //get module id from database
	public $alias_category = "Blog";
	
	public function __construct()
	{
		parent::__construct();
               if( ! $_SESSION)
                {
                    session_start();
                }
		if(empty($_SESSION['admin_data'])){
			session_destroy();
			redirect(BASE_URL_BACKEND."/signin");
			exit();
		}
		
		$this->load->model(array('backend/Model_menu_frontend','backend/Model_blog','backend/Model_subscribe','backend/Model_tagging','backend/Model_gallery','backend/Model_alias', 'backend/Model_language','backend/Model_logcms'));
		$this->load->helper(array('funcglobal','menu','accessprivilege','alias'));
		
                $module_name=  $this->uri->segment(2);
                $getmodule = $this->Model_blog->getModule($module_name);
                foreach ($getmodule as $gm) {
                 $this->module_id = $gm->module_id;
                 $this->section = $gm->module_group_id;
			     $_SESSION['module_id']=$this->module_id;
                }
		//get menu from helper menu
		$this->arrMenu = menu();
		$this->data = array();
                $this->data['ListMenu'] = $this->arrMenu;
                $this->data['CountMenu'] = count($this->arrMenu);
		$this->data['controller'] = $module_name;
                $this->data['MenuBlog'] = $this->Model_menu_frontend->getMenuContent($_SESSION['module_id']);
                $this->data['Blogcategory'] = $this->Model_blog->getBlogCategory();
		//check privilege module
		$this->privilege = accessprivilegeuserlevel($_SESSION['admin_data']['user_level_id'], $_SESSION['module_id']);
		$this->breadcrump = breadCrump($_SESSION['module_id']);
	}
	
	public function index()
	{
		$this->view();
	}
	
	function view(){
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $_SESSION['module_id'];
		$this->data['breadcrump'] = $this->breadcrump;
		
		$searchkey = "";
		$searchby = "";
		$where = "";
		$orderBy = "";
		$perpage = "";
		
		if(isset($_POST["tbSearch"])){
			$_SESSION["searchkey".$this->module_id] = '';
			$_SESSION["searchby".$this->module_id] = '';
			$_SESSION["perpage".$this->module_id] = '';
			
			$searchkey = $this->security->xss_clean(secure_input($_POST['searchkey']));
			$searchby = $this->security->xss_clean(secure_input($_POST['searchby']));
			$perpage = $this->security->xss_clean(secure_input($_POST['perpage']));
			
									
			$pesan = array();

			if ($searchkey=="") {
				$pesan[] = 'Keyword search is empty';
			} else if ($searchby=="") {
				$pesan[] = 'Search by has not been choose';
			}
			
			if (! count($pesan)==0 ) {
				foreach ($pesan as $indeks=>$pesan_tampil) {
					$_SESSION["searchkey".$this->module_id] = '';
					$_SESSION["searchby".$this->module_id] = '';
					$_SESSION["perpage".$this->module_id] = '';
				}
			} else {
				$_SESSION["searchkey".$this->module_id] = $searchkey;
				$_SESSION["searchby".$this->module_id] = $searchby;
				$_SESSION["perpage".$this->module_id] = $perpage;
					
				if(isset($_POST['searchkey'])){
					$searchkey = $_SESSION["searchkey".$this->module_id];
				}
				if(isset($_POST['searchby'])){
					$searchby = $_SESSION["searchby".$this->module_id];
				}
				
				if($searchkey != "" && $searchby != ""){
					$where   =   " WHERE ".$searchby." LIKE '%". $searchkey ."%' ";
				}
			}	
		} else {
			$searchkey = @$_SESSION["searchkey".$this->module_id];
			$searchby = @$_SESSION["searchby".$this->module_id];
			
			if($searchkey != "" && $searchby != ""){
				$where   =   " WHERE ".$searchby." LIKE '%". $searchkey ."%' ";
			}
			
			if(isset($_POST['perpage'])){
				$perpage = $this->security->xss_clean(secure_input($_POST['perpage'])); 
				$_SESSION["perpage".$this->module_id] = $perpage;
			} else {
				$perpage = @$_SESSION["perpage".$this->module_id];
				
				if($perpage == ""){
					$perpage = PER_PAGE;
				}
			}
		}
		
		$orderBy = "ORDER BY a.blog_order Asc";
		
		$cond 			= $where." ".$orderBy;

		$ListBlog = $this->Model_blog->getListBlog($this->data['modul_id'],$cond);
		
		$this->data["ListBlog"] = $ListBlog;
		
		//extract privilege
		$this->data["list"] = $this->privilege[0];
		$this->data["view"] = $this->privilege[1];
		$this->data["add"] = $this->privilege[2];
		$this->data["edit"] = $this->privilege[3];
		$this->data["publish"] = $this->privilege[4];
		$this->data["approve"] = $this->privilege[5];
		$this->data["delete"] = $this->privilege[6];
		$this->data["order"] = $this->privilege[7];
		
		if($this->data["list"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$this->data['searchkey'] = $searchkey;
		$this->data['searchby'] = $searchby;
		$this->data['perpage'] = $perpage;
               
		
		//$this->data['total'] = $total_rows;
		
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/Blog/list');
	}
	
	function add(){
		//extract privilege
		$this->data["add"] = $this->privilege[2];
		
		if($this->data["add"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		$this->data['tagging']=  $this->Model_tagging->getListTagging('');
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/Blog/add',$this->data);
	}
	
	function doAdd(){
		//extract privilege
		$this->data["add"] = $this->privilege[2];
		
		if($this->data["add"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$tb = $_POST['tbSave'];
		if (!$tb) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		}
		
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		
                $blogtag = $_POST['blogtag'];
		
		$blogtag_new = "";
		if(!empty($blogtag)){
			foreach($blogtag as $tag){
				$cekTagging = $this->Model_tagging->checkTagging($tag);
				$countTagging = count($cekTagging);
				if($countTagging < 1) $taggingid = $this->Model_tagging->insertTagging($tag);
				$blogtag_new .= $tag.",";
			}
			$blogtag_new = substr($blogtag_new, 0, -1);
		}
		$blog_title = $this->security->xss_clean(secure_input($_POST['blog_title']));
		$blog_shortdesc = secure_input_editor($_POST['blog_shortdesc']);
		$blog_desc = secure_input_editor($_POST['blog_desc']);
                
                $blog_publish_date = secure_input_editor($_POST['blog_publish_date']);
               
		$blog_imageurl = $this->security->xss_clean(secure_input($_POST['blog_imageurl']));
		$blog_alias = $this->security->xss_clean(secure_input($_POST['blog_alias']));
		$blog_metadescription = $this->security->xss_clean(secure_input($_POST['blog_metadescription']));
		$blog_metakeywords = $this->security->xss_clean(secure_input($_POST['blog_metakeywords']));
               
                $category_title = $this->security->xss_clean(secure_input($_POST['category_title']));
                if ($category_title == ''){
                    $cat = $this->security->xss_clean(secure_input($_POST['category_id']));
                }
                else {
                    $cat = $this->Model_blog->insertCategory($category_title);  
                }
               $category_id =$cat;
                
                
		
		$pesan = array();
		// Validasi data
		if ($blog_title=="") {
			$pesan[] = 'Blog Title is empty';
		} 
		 else if ($blog_desc=="") {
			$pesan[] = 'Blog Description is empty';
		} 
		else if ($blog_publish_date=="") {
			$pesan[] = 'blog publish date is empty';
		} 
		if (! count($pesan)==0 ) {
			foreach ($pesan as $indeks=>$pesan_tampil) {
				$this->data['error'] = $pesan_tampil;
				
				$this->data['blog_title']=$blog_title;
                                $this->data['category_title']=$category_title;
				$this->data['blog_shortdesc']=$blog_shortdesc;
				$this->data['blog_desc']=$blog_desc;
				$this->data['blog_imageurl']=$blog_imageurl;
				$this->data['blog_alias']=$blog_alias;
				$this->data['blog_metadescription']=$blog_metadescription;
				$this->data['blog_metakeywords']=$blog_metakeywords;
					
				$this->load->view('backend/header',$this->data);
				$this->load->view('backend/Blog/add',$this->data);
			}
		} else {
			$cekBlog = $this->Model_blog->checkBlog($blog_title);
			$countBlog = count($cekBlog);
			
			if ($countBlog > 0 ) {
				$this->data['error']='Blog Title '.$blog_title.' already exist';
				
				$this->data['blog_title']=$blog_title;
                              
				$this->data['blog_shortdesc']=$blog_shortdesc;
				$this->data['blog_desc']=$blog_desc;
                               
				$this->data['blog_imageurl']=$blog_imageurl;
				$this->data['blog_alias']=$blog_alias;
				$this->data['blog_metadescription']=$blog_metadescription;
				$this->data['blog_metakeywords']=$blog_metakeywords;
				
				$this->load->view('backend/header',$this->data);
				$this->load->view('backend/Blog/add',$this->data);
			} else {
				$blog_imageurl = str_replace(BASE_URL,"",$blog_imageurl);
				$countAlias = 0;
				
				if(!empty($blog_alias)) {
					$alias = generateAlias($blog_alias);
					$cekAlias = $this->Model_alias->checkAliasCategory($alias,$this->alias_category);
					$countAlias = count($cekAlias);
				} else {
					$alias = generateAlias($blog_title);
					$cekAlias = $this->Model_alias->checkAliasCategory($alias,$this->alias_category);
					$countAlias = count($cekAlias);
				}
				
				if ($countAlias > 0 ) {
					$this->data['error']='Alias '.$alias.' already exist from title '.$blog_title.'';
				
					$this->data['blog_title']=$blog_title;
					$this->data['blog_shortdesc']=$blog_shortdesc;
					$this->data['blog_desc']=$blog_desc;
					$this->data['blog_imageurl']=$blog_imageurl;
					$this->data['blog_alias']=$blog_alias;
					$this->data['blog_metadescription']=$blog_metadescription;
					$this->data['blog_metakeywords']=$blog_metakeywords;
				
					$this->load->view('backend/header',$this->data);
					$this->load->view('backend/Blog/add',$this->data);
				} else {
                                        $resize =$this->security->xss_clean(secure_input($_POST['blog_imageurl']));
                                        $thumbnail=$this->resizing($resize); 
					$blog_id = $this->Model_blog->insertBlog($category_id,$blog_title,$blog_desc,$blog_imageurl,$blog_publish_date,$alias,$blogtag_new,$blog_metadescription,$blog_metakeywords,$blog_shortdesc);
					if(!empty($blog_id)) {
						$aliasid = $this->Model_alias->insertAlias($blog_id,$this->alias_category,$alias,$this->data['controller']."/detail/".$blog_id);
					}
					
					$log_module = "Add ".$this->module;
					$log_value = $blog_id." | ".$blog_title." | ".$blog_shortdesc." | ".$blog_desc." | ".$blog_imageurl." | ".$alias." | ".$blog_metadescription." | ".$blog_metakeywords;
					$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
					
					redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
				}
				
			}	
		}	
	}
	
	function active($id){
		if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		}
		
		//extract privilege
		$this->data["approve"] = $this->privilege[5];
		
		if($this->data["approve"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$rsBlog = $this->Model_blog->getBlog($id); 
		$title = $rsBlog[0]['blog_title'];
                $active_status = abs($rsBlog[0]['blog_active_status']-1);
                if($active_status==1){
                    $this->senSubscribe($rsBlog[0]['blog_id'],$rsBlog[0]['blog_title'],$rsBlog[0]['blog_alias']);
                }
		$active = $this->Model_blog->activeBlog($id);
		createRouteAlias(); //create route alias
		
		if($active_status == 1){
			$log_module = "Active ".$this->module;
		} else {
			$log_module = "Inactive ".$this->module;
		}
		$log_value = $id." | ".$title." | ".$active_status;
		$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
                
                $this->generateBlog();
		redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
		
	}
	
	function delete($id){
		if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		}
		
		//extract privilege
		$this->data["delete"] = $this->privilege[6];
		
		if($this->data["delete"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$rsBlog = $this->Model_blog->getBlog($id); 
		$title = $rsBlog[0]['blog_title'];
               
                $category_id = $rsBlog[0]['category_id'];
               
                
		$delete = $this->Model_blog->deleteBlog($id);
		$delete_alias = $this->Model_alias->deleteAlias($id, $this->alias_category);
		createRouteAlias(); //create route alias
		
		$log_module = "Delete ".$this->module;
		$log_value = $id." | ".$title;
		$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
                
                $this->generateBlog();
		
                redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
	}
        public function deleteGallery($id){
            if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		}
		
		//extract privilege
		$this->data["delete"] = $this->privilege[6];
		
		if($this->data["delete"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
                $where = "";
                $orderBy = "ORDER BY a.gallery_id DESC";		
		$cond 			= $where." ".$orderBy;
                $ListGallery = $this->Model_gallery->getListGallery($id, $cond);
                
                foreach($ListGallery as $gallery){  
                        $image_path = './assets/images/'.$gallery['gallery_image']; 
                        $image_resize = './assets/images/resized/'.$gallery['gallery_image'];         
                        $image_thumb = './assets/images/thumb/'.$gallery['gallery_image']; 

                        if($gallery['gallery_image'] != 'default_icon.png'){
                        unlink($image_path);
                        unlink($image_resize);
                        unlink($image_thumb);
                           }     
                        $this->Model_gallery->deleteGallery($gallery['gallery_id']);

                
                }           
            
        }
	public function edit($id){
		if (empty($id)) {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		}

		//extract privilege
		$this->data["edit"] = $this->privilege[3];
		
		if($this->data["edit"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		$this->data['tagging']=  $this->Model_tagging->getListTagging('');
		$rsBlog = $this->Model_blog->getBlog($id);  // mengambil database dari model untuk dikirim ke view
		
                $countBlog = count($rsBlog);
		
		$this->data['rsBlog'] = $rsBlog;
		$this->data['countBlog'] = $countBlog;
		
		$this->load->view('backend/header',$this->data);
		$this->load->view('backend/Blog/edit',$this->data);
	}
	
	public function doEdit($id){
		$tb = $_POST['tbEdit'];
		if (!$tb OR $id == '') {
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		}
		
		//extract privilege
		$this->data["edit"] = $this->privilege[3];
		
		if($this->data["edit"] == 0){
			echo "<script>alert('Can\'t Access Module');window.location.href='".BASE_URL_BACKEND."/home';</script>";
			die;
		}
		
		$admin_data = $_SESSION['admin_data'];
		$this->data['admin_data'] = $admin_data;
		$this->data['section'] = $this->section; 
		$this->data['modul_id'] = $this->module_id;
		$this->data['breadcrump'] = $this->breadcrump;
		
		$rsBlog = $this->Model_blog->getBlog($id);  // mengambil database dari model untuk dikirim ke view
		$countBlog = count($rsBlog);
		
		$this->data['rsBlog'] = $rsBlog;
		$this->data['countBlog'] = $countBlog;
                
		$category_id = $this->security->xss_clean(secure_input($_POST['category_id']));
		$blog_title = $this->security->xss_clean(secure_input($_POST['blog_title']));
		$blog_shortdesc = secure_input_editor($_POST['blog_shortdesc']);
		$blog_titleOld = $this->security->xss_clean(secure_input($_POST['blog_titleOld']));
		$blog_desc = secure_input_editor($_POST['blog_desc']);
		$blog_imageurl = $this->security->xss_clean(secure_input($_POST['blog_imageurl']));
                $blog_publish_date = secure_input_editor($_POST['blog_publish_date']);
		$blog_alias = $this->security->xss_clean(secure_input(@$_POST['blog_alias']));
		$blog_metadescription = $this->security->xss_clean(secure_input($_POST['blog_metadescription']));
		$blog_metakeywords = $this->security->xss_clean(secure_input($_POST['blog_metakeywords']));
		$blogtag_new = $this->security->xss_clean(secure_input($_POST['blogtag']));
                
		
		$pesan = array();
		// Validasi data
		if ($blog_title=="") {
			$pesan[] = 'Blog Title is empty';
		} else if ($blog_desc=="") {
			$pesan[] = 'Blog Description is empty';
		} 
		
		
		if (! count($pesan)==0 ) {
			foreach ($pesan as $indeks=>$pesan_tampil) {
				$this->data['error'] = $pesan_tampil;
				
				$this->load->view('backend/header',$this->data);
				$this->load->view('backend/Blog/edit',$this->data);
			}
		} else {
			$cekBlog = $this->Model_blog->checkBlog($blog_title);
			$countBlog = count($cekBlog);
			
			if($blog_title == $blog_titleOld){
				$countBlog = 0;
			}
			
			if ($countBlog > 0 ) {
				$this->data['error']='Blog Title '.$blog_title.' already exist';

				$this->load->view('backend/header',$this->data);
				$this->load->view('backend/Blog/edit',$this->data);
			} else {
				$blog_imageurl = str_replace(BASE_URL,"",$blog_imageurl);
				$countAlias = 0;
				
				if(!empty($blog_alias)) {
					$alias = generateAlias($blog_alias);
					$cekAlias = $this->Model_alias->checkAliasCategory($alias,$this->alias_category);
					$countAlias = count($cekAlias);
				} else {
					$alias = generateAlias($blog_title);
					$cekAlias = $this->Model_alias->checkAliasCategory($alias,$this->alias_category);
					$countAlias = count($cekAlias);
				}
				
				if($blog_title == $blog_titleOld){
					$countAlias = 0;
				}
				
				if ($countAlias > 0 ) {
					$this->data['error']='Alias '.$alias.' already exist from title '.$blog_title.'';
					
					$this->load->view('backend/header',$this->data);
					$this->load->view('backend/Blog/edit',$this->data);
				} else {
                                        $resize =$this->security->xss_clean(secure_input($_POST['blog_imageurl']));
                                        $thumbnail=$this->resizing($resize); 
					$update = $this->Model_blog->updateBlog($id,$category_id,$blog_title,$blog_desc,$blog_imageurl,$blog_publish_date,$alias,$blogtag_new,$blog_metadescription,$blog_metakeywords,$blog_shortdesc);
					if($update) {
						$this->Model_alias->updateAlias($id,$alias,$this->alias_category);
					}
					
					createRouteAlias(); //create route alias
					
					$log_module = "Edit ".$this->module;
					$log_value = $id." | ".$blog_title." | ".$blog_shortdesc." | ".$blog_desc." | ".$blog_imageurl." | ".$alias." | ".$blog_metadescription." | ".$blog_metakeywords;
					$insertlog = $this->Model_logcms->insertLogCMS($log_module,$log_value);
					
					//Cache JSON Blog
					 $this->generateBlog();
					
					//End Cache JSON Blog
					
					redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
				}
			}	
		}
		
	}
	public function doOrder(){
		
		$order = $this->security->xss_clean($_POST['order']);
		
		if($order == ""){
			redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
			exit();
		} 
		
		foreach($order as $id => $ordervalue){
			$this->Model_blog->updateOrderBlog($id,$ordervalue);
                        echo $ordervalue;
		}
		 $this->generateBlog();
		redirect(BASE_URL_BACKEND.'/'.$this->data['controller']);
	}

        function generateBlog(){
                $ListBlog			= $this->Model_blog->generateBlog(" WHERE blog_active_status = 1 ORDER BY blog_id DESC limit 0,5");
		$countBanner		= count($ListBlog);
		//createCacheBanner($rsBanner,"bannerhome");
               createCache($ListBlog,"blog");
        }
        
        function senSubscribe($id,$title,$alias){
            
                if ($alias!= ''){
                    $url_blog = BASE_URL.'/'.$alias;}
                    else {
                    $url_blog = BASE_URL.'/blog/detail/'.$id;
                    
                    }
            
            
                $cond = " Where a.subscribe_active_status =1";

		$ListSubscribe = $this->Model_subscribe->getListSubscribe($cond);
                
                foreach ($ListSubscribe as $subs) {
                    $email = $subs['subscribe_email'];
                    $verification_code = $subs['subscribe_verification_code'];
                
                        $subject = "Properti 57 - BLOG Terbaru ";
                        $message_email = "<html><head></head><body>";
                        $message_email .= "Dear<br>"; 
                        $message_email .= "".$email."<br>";
                        $message_email .= "<br>";
                        $message_email .= "<a href=".$url_blog.">";
                        $message_email .= $title; 
                        $message_email .= "</a> <br>";		

                        $message_email.= "<br>"; 
                        $message_email .= "Silahkan klik link berikut untuk menonaktifkan pemberitahuan dari kami <br>";
                        $message_email .= "<a href=".BASE_URL."/Suscribe/noActive/" .$verification_code.">";
                        $message_email .= BASE_URL."/Berhenti Berlangganan/"; 
                        $message_email .= "</a> <br>";
                        $message_email.= "========================="; 
                        $message_email.= "<br>"; 
                        $message_email .= "Powered by<br>";
                        $message_email .= "<a href='".BASE_URL."'>";
                        $message_email .= BASE_URL; 
                        $message_email .= "</a> <br>";
                        $message_email .= "<img src='".IMAGES_BASE_URL."/logo.png' alt='' />";
                        $message_email .= "</body></html>";
                        $header = "";
                        $header .= "Reply-To: balkat.com <noreply@".$_SERVER['SERVER_NAME'].">\r\n";
                        $header .= "Return-Path: balkat.com <noreply@".$_SERVER['SERVER_NAME'].">\r\n";
                        $header .= "From: balkat.com <noreply@".$_SERVER['SERVER_NAME'].">\r\n";
                        $header .= "Organization: ".$_SERVER['SERVER_NAME']." \r\n";
                        $header .= "X-Priority: 3\r\n";
                        $header .= "MIME-Version: 1.0\r\n";
                        $header .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

                        mail($email, $subject, $message_email, $header);   
                                        
                }
            
        }
        
       public function resizing($resize) {
        $imageurl = str_replace(BASE_URL,PATH_PROJECT,$resize);
        $image_name = end((explode('/', $resize)));
       // echo PATH_PROJECT.$image_name;
        
        $config['image_library'] = 'gd2';
        $config['source_image'] = $imageurl;
        $config['new_image'] = PATH_ASSETS.'/file_upload/thumbs/'.$image_name;
        
        $config['create_thumb'] = FALSE;
        $config['maintain_ratio'] = FALSE;
        $config['width']         = 400;
        $config['height']       = 250;
        $config['x_axis']         = 150;
        $config['y_axis']       = 150;
        $this->load->library('image_lib', $config);
        $this->image_lib->resize();
        //$this->image_lib->crop();
       
    } 
        
}